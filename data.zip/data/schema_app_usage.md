# Schema: app_usage.csv

- member_id (int): Unique member identifier.
- event_type (string): Application event type; in this dataset, values are "session".
- timestamp (datetime, UTC): Event timestamp within the fixed observation window.